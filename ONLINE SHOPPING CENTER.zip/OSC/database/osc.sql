-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 05, 2022 at 03:04 PM
-- Server version: 5.7.36
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `osc`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `fname` varchar(100) NOT NULL,
  `mname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `dateofbirth` date NOT NULL,
  `gender` varchar(8) NOT NULL,
  `mo1` bigint(13) NOT NULL,
  `password` varchar(20) NOT NULL,
  `email` varchar(70) NOT NULL,
  `address` varchar(250) NOT NULL,
  `country` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `pincode` int(25) NOT NULL,
  `image` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mo1` (`mo1`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `images` (`image`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `fname`, `mname`, `lname`, `dateofbirth`, `gender`, `mo1`, `password`, `email`, `address`, `country`, `state`, `city`, `pincode`, `image`) VALUES
(1, 'HARSH', 'HASMUKHBHAI', 'JOLAPARA', '2022-03-02', 'MALE', 8128203856, 'harsh@1703', 'harshj0107@gmail.com', 'XYZABCDEFGHI', 'INDIA', 'GUJRAT', 'RAJKOT', 360004, '7219-Z-d-Deadpool_1989.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `analysis`
--

DROP TABLE IF EXISTS `analysis`;
CREATE TABLE IF NOT EXISTS `analysis` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `pname` varchar(200) NOT NULL,
  `price` int(20) NOT NULL,
  `image` varchar(200) NOT NULL,
  `customer` varchar(200) NOT NULL,
  `date` date NOT NULL,
  `time` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=43 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `analysis`
--

INSERT INTO `analysis` (`id`, `pname`, `price`, `image`, `customer`, `date`, `time`) VALUES
(6, 'MIPOWER BANK 20000Mah', 1800, '4402-W-u-71lVwl3q-kL._SX679_.jpg', 'DARSHANBHAI GOHEL', '2022-05-03', '10:09:02am'),
(5, 'OBAGE MT-600 SPEAKER', 4500, '5174-Z-i-71re+OcIBBL._SX522_.jpg', 'HARSH JOLAPARA', '2022-05-03', '10:09:02am'),
(8, 'MI WIRELESS HEADPHONES', 1600, '3318-P-z-71s9FMKzr+L._SX522_.jpg', 'HARSH JOLAPARA', '2022-05-03', '10:09:02am'),
(9, 'OPPO A15S', 11000, '2379-Z-o-71zbz1O+hqL._SX679_.jpg', 'HARSH JOLAPARA', '2022-05-03', '10:09:02am'),
(10, 'OPPO A15S', 11000, '2379-Z-o-71zbz1O+hqL._SX679_.jpg', 'HARSH JOLAPARA', '2022-05-03', '10:09:02am'),
(42, 'boAt airpodes', 1400, '5587-D-q-315sZxguX0L.jpg', 'HARSH JOLAPARA', '2022-05-05', '04:56:12pm'),
(12, 'Redmi Note 11', 14000, '5153-C-g-81zLNgcvlaL._SX679_.jpg', 'HARSH JOLAPARA', '2022-05-03', '10:09:02am'),
(17, 'Redmi Note 11', 14000, '5153-C-g-81zLNgcvlaL._SX679_.jpg', 'HARSH JOLAPARA', '2022-05-02', '10:09:02am'),
(18, 'ARDUINO', 600, '2723-R-u-61vLP87u0sL._SX522_.jpg', 'HARSH JOLAPARA', '2022-05-02', '10:09:02am'),
(19, 'Redmi Note 11', 14000, '5153-C-g-81zLNgcvlaL._SX679_.jpg', 'HARSH JOLAPARA', '2022-05-03', '10:09:02am'),
(20, 'Fastrack Reflex 3.0 WATCH', 1900, '9172-Q-t-61u2Rr7tBRL._UX522_.jpg', 'HARSH JOLAPARA', '2022-05-04', '10:09:02am'),
(21, 'Fastrack Reflex 3.0 WATCH', 1900, '9172-Q-t-61u2Rr7tBRL._UX522_.jpg', 'HARSH JOLAPARA', '2022-05-04', '10:09:02am'),
(23, 'Amzon Alexa', 2000, '2133-I-b-61+QNG8IiPL._SX679_.jpg', 'HARSH JOLAPARA', '2022-05-04', '10:09:02am'),
(25, 'boAt airpodes', 1400, '5587-D-q-315sZxguX0L.jpg', 'HARSH JOLAPARA', '2022-05-04', '11:16:58am'),
(24, 'Amzon Alexa', 2000, '2133-I-b-61+QNG8IiPL._SX679_.jpg', 'vatsal ramani', '2022-05-04', '10:12:53am');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
CREATE TABLE IF NOT EXISTS `login` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `fname` varchar(20) NOT NULL,
  `mname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `birthdate` date NOT NULL,
  `gender` varchar(7) NOT NULL,
  `mo1` bigint(13) NOT NULL,
  `password` varchar(25) NOT NULL,
  `email` varchar(40) NOT NULL,
  `address` varchar(100) NOT NULL,
  `country` varchar(10) NOT NULL,
  `state` varchar(10) NOT NULL,
  `city` varchar(10) NOT NULL,
  `pincode` int(20) NOT NULL,
  `image` varchar(50) DEFAULT NULL,
  `status` int(2) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `mo1` (`mo1`),
  UNIQUE KEY `image` (`image`)
) ENGINE=MyISAM AUTO_INCREMENT=104 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `fname`, `mname`, `lname`, `birthdate`, `gender`, `mo1`, `password`, `email`, `address`, `country`, `state`, `city`, `pincode`, `image`, `status`) VALUES
(45, 'harsh', 'hasmukhbhai', 'JOLAPARA', '2021-01-01', 'MALE', 9426638056, 'harsh@1703', 'hsssjolapara@gmail.com', 'kadiyanagar block no. 4', 'India', 'gujrat', 'rajkot', 360004, '40.jpeg', 1),
(66, 'HARSH', 'HASMUKHBHAI', 'JOLAPARA', '2021-01-01', 'MALE', 9427965269, 'harsh@1703', 'harshj0107@gmail.com', 'near ankur vidhyalaya', 'india', 'gujrat', 'rajkot', 360004, '6.jpeg', 1),
(68, 'PRAYAG', 'D.', 'SHETH', '2021-01-01', 'MALE', 4646464664, 'prayag@12', 'developer404.sp@gmail.com', 'rajkot                       ', 'india', 'gujrat', 'rajkot', 360004, '1.png', 1),
(69, 'harsh', 'h.', 'jolapara', '2021-01-01', 'MALE', 8888888888, 'harsh@1703', 'tapan123@gmail.com', '--------------                       ', '------', '--------', '---------', 46646464, '9.jpeg', 0),
(74, 'KASHYAP', 'P', 'PATHAK', '2021-01-01', 'MALE', 2222222222, 'kashyap@1234', 'kashyap1234@gmail.com', 'bhaktinagar                       ', 'india', 'gujrat', 'rajkot', 11111111, '13.jpeg', 0),
(103, 'DARSHANBHAI', 'D', 'GOHEL', '2021-01-01', 'MALE', 1234567889, 'darshan@123', 'darshangohel311@gmail.com', 'address', 'india', 'gujrat', 'rajkot', 123456, '61.jpeg', 1),
(101, 'harsh', 'hasmukhbhai', 'JOLAPARA', '2021-01-01', 'MALE', 7895556870, 'harsh@1703', 'hhj49@gmail.com', 'address', 'India', 'gujrat', 'rajkot', 360004, '62.jpeg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
CREATE TABLE IF NOT EXISTS `product` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pname` varchar(50) NOT NULL,
  `price` int(30) NOT NULL,
  `quantity` int(20) NOT NULL,
  `detail` varchar(300) NOT NULL,
  `imgurl` varchar(100) NOT NULL,
  `status` int(2) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=49 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `pname`, `price`, `quantity`, `detail`, `imgurl`, `status`) VALUES
(26, 'Redmi Note 11', 14000, 17, 'Redmi Note 11 (Horizon Blue, 4GB RAM, 64GB Storage) | 90Hz FHD+ AMOLED Display | QualcommÂ® Snapdragonâ„¢ 680-6nm | Alexa Built-in', '5153-C-g-81zLNgcvlaL._SX679_.jpg', 1),
(46, 'boAt airpodes', 1400, 14, '(Renewed) boAt Airdopes 381 N TWS Earbuds with IWP Technology, ASAP Charge & Upto 20H Playback (Teal Blue)', '5587-D-q-315sZxguX0L.jpg', 1),
(24, 'OBAGE MT-600 SPEAKER', 4500, 2, 'OBAGE MT-600 Woody 35 Watt 2.1 Channel Wireless Bluetooth Tower Speaker (Brown)', '5174-Z-i-71re+OcIBBL._SX522_.jpg', 1),
(17, 'OPPO A15S', 11000, 7, 'OPPO A15s (Rainbow Silver, 4GB RAM, 64GB Storage) With No Cost EMI/Additional Exchange Offers', '2379-Z-o-71zbz1O+hqL._SX679_.jpg', 1),
(18, 'MIPOWER BANK 20000Mah', 1800, 4, 'Mi Power Bank 3i 20000mAh | 18W Fast PD Charging | Input- Type C and Micro USB| Triple Output | Sandstone Black', '4402-W-u-71lVwl3q-kL._SX679_.jpg', 1),
(19, 'MI WIRELESS HEADPHONES', 1600, 8, 'MI Super Bass Bluetooth Wireless On Ear Headphones with Mic (Black and Red)', '3318-P-z-71s9FMKzr+L._SX522_.jpg', 1),
(20, 'Fastrack Reflex 3.0 WATCH', 1900, 10, 'Fastrack Reflex 3.0 Unisex Activity Tracker - Full Touch, Color Display, Heart Rate Monitor, Dual- Tone Silicone Strap and up to 10 Days Battery Life', '9172-Q-t-61u2Rr7tBRL._UX522_.jpg', 1),
(21, 'QUICK HEAL TOTAL SECURITY', 1100, 7, 'Quick Heal | Total Security | 1 User | 1 Year | Email Delivery in 2 hours - no CD', '5628-Z-f-619ZtwshdqL._SX679_.jpg', 1),
(22, 'ARDUINO', 600, 10, 'Sparklebox Programmable Microcontroller with USB wire| Arduino Uno with USB Cable| Uno Board with ATmega328 chip', '2723-R-u-61vLP87u0sL._SX522_.jpg', 0),
(45, 'Amzon Alexa', 2000, 7, 'Echo Dot (3rd Gen), Certified Refurbished, Black â€“ Improved smart speaker with Alexa â€“ Like new, backed with 1-year warranty', '2133-I-b-61+QNG8IiPL._SX679_.jpg', 1),
(48, 'ONE PLUS TV', 16000, 10, 'OnePlus 80 cm (32 inches) Y Series HD Ready LED Smart Android TV 32Y1 (Black) (2020 Model)', '6009-E-d-71vZypjNkPS._SX522_.jpg', 1),
(47, 'GAMING HP KEYBOARD', 1200, 4, 'HP K500F Backlit Membrane Wired Gaming Keyboard with Mixed Color Lighting, Metal Panel with Logo Lighting, 26 Anti-Ghosting Keys, and Windows Lock Key', '6297-O-q-71f+Iz89ozL._SX679_.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `seller`
--

DROP TABLE IF EXISTS `seller`;
CREATE TABLE IF NOT EXISTS `seller` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `fname` varchar(20) NOT NULL,
  `mname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `birthdate` date NOT NULL,
  `gender` varchar(7) NOT NULL,
  `mo1` bigint(13) NOT NULL,
  `password` varchar(25) NOT NULL,
  `email` varchar(40) NOT NULL,
  `address` varchar(100) NOT NULL,
  `country` varchar(10) NOT NULL,
  `state` varchar(10) NOT NULL,
  `city` varchar(10) NOT NULL,
  `pincode` int(20) NOT NULL,
  `image` varchar(50) NOT NULL,
  `status` int(2) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `mo1` (`mo1`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seller`
--

INSERT INTO `seller` (`id`, `fname`, `mname`, `lname`, `birthdate`, `gender`, `mo1`, `password`, `email`, `address`, `country`, `state`, `city`, `pincode`, `image`, `status`) VALUES
(6, 'HARSH', 'H.', 'JOLAPARA', '2021-01-01', 'MALE', 8128203856, 'harsh@1703', 'harshj0107@gmail.com', 'address', 'india', 'gujrat', 'rajkot', 123456, '2113-G-s-Superman_46.jpeg', 1),
(2, 'harsh', 'hasmukhbhai', 'JOLAPARA', '2021-01-01', 'MALE', 9426638056, 'harsh@1703', 'hsssjolapara@gmail.com', 'address', 'India', 'gujrat', 'rajkot', 360004, '3288-L-z-378546.jpg', 0),
(3, 'harsh', 'h.', 'jolapara', '2021-01-01', 'MALE', 5546646464, 'harsh@1703', 'harshj07@gmail.com', 'address', 'india', 'gujrat', 'rajkot', 5465465, '5511-R-j-Ironman Pool_1581.jpeg', 1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
