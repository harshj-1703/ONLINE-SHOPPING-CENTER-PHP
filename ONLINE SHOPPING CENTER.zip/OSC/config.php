<?php
$keyId = 'rzp_test_MtOk2EPnPUWDN3';
$keySecret = 'YJJ32cIoDkJyILf5qcWtamiV';
$displayCurrency = 'INR';
error_reporting(E_ALL);
ini_set('display_errors', 1);
